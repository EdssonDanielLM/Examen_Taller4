export interface ExamenDto {
    description: string;
    isDone: boolean;
}