import { Controller, Get, Render } from '@nestjs/common';
import { AppService } from './app.service';

@Controller('/')
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get('/')
  @Render('index')
  getHello() {
    return { message: 'Hola Edsson Nestjs' };
  }
  @Get('/examen')
  @Render('examen')
  Hello() {
    return { message: 'Hola Edsson Nestjs' };
  }
}
