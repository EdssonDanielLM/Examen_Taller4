import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ExamenController } from './examen/examen.controller';
import { ExamenService } from './examen/examen.service';
import { ExamenModule } from './examen/examen.module';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';

@Module({
  imports: [
  
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
